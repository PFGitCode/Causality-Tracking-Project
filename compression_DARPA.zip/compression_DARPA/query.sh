USERNAME="peng"
PASSWARD="1234"
DST="3"
STIME="1554523206495"

javac DataCompress/*.java

java -classpath DataCompress/postgresql-42.2.6.jar:./ DataCompress.query $USERNAME $PASSWARD $DST $STIME