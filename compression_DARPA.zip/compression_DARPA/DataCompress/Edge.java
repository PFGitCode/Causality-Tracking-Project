  package DataCompress;	
  public class Edge {
    int srcindex, dstindex;
    boolean selfMerged;
    boolean multiMerged;
    String id, sequence, threadId, srcid, dstid, predicateObjectPath, time, hostId, total;
    public Edge() {
    }
    public Edge(String line) {
      int i = 0;
      this. total = line;
      String[] arrayString = line.split(",");
      this.id = arrayString[i++];
      this.sequence = arrayString[i++];
      this.threadId = arrayString[i++];
      this.srcid = arrayString[i++];
      this.dstid = arrayString[i++];
      this.predicateObjectPath = arrayString[i++];
      this.time = arrayString[i++];
      this.hostId = arrayString[i++];
      System.out.println(this.sequence);
      // this.total = this.id + ","+this.sequence + ","+ this.threadId + ","+
  	  	// this.srcid + ","+ this.dstid + ","+ this.predicateObjectPath + "," + this.time + "," +this.hostId;
    }

   //   public String RiceEncode(){
   //    //System.out.println(seqM);
   //   	long nstarttime = Ricecoding.encode(Long.parseLong(this.starttime),timeM);
 	 //    long nstarttime_seq = Ricecoding.encode(Long.parseLong(this.starttime_seq),seqM);
 	 //  	long nendtime = Ricecoding.encode(Long.parseLong(this.endtime),timeM);
  	//   long nendtime_seq = Ricecoding.encode(Long.parseLong(this.endtime_seq),seqM);
   //    this.starttime = Long.toString(nstarttime);
   //    this.starttime_seq = Long.toString(nstarttime_seq);
   //    this.endtime = Long.toString(nendtime);
   //    this.endtime_seq = Long.toString(nendtime_seq);

  	//   this.total = this.id +","+ starttime+ "," + starttime_seq+ ","+
  	//   endtime+ ","+ endtime_seq + ","+ this.failure+ "," + this.srcid+ ","
  	//   +this.dstid+ ","+this.optype+","+this.agentid+ "," + this.path+ ","+this.access+ ","+ this.amount+ ","+this.summarized;
  	//   return this.total;
	  // }
  }