// package DataCompress;	
// import java.util.*;
// import java.io.BufferedReader;
// import java.io.FileReader;
// import java.io.BufferedWriter;
// import java.io.FileWriter;
// import java.io.IOException;
// import java.lang.*;
// import java.util.ArrayList;
// import static java.lang.Math.min;
// import java.util.*;
// import java.sql.ResultSet;
// import java.sql.Connection;
// import java.sql.Statement;
// import java.sql.ResultSetMetaData;

// public class query{
// 	public static void main(String[] args){
// 		String dbAddress = "jdbc:postgresql://localhost:5432/compresseddb", user = args[0], 
// 		passwd = args[1], dbname = "compresseddb"; // Set up database info
// 		Map<Integer, Integer> nodes2Newnode = new HashMap();
// 		Map<Integer, Set<Integer>> newnode2node = new HashMap();
// 		Long timeM = 0L, seqM = 0L;
// 		try{
// 			BufferedReader reader = new BufferedReader(new FileReader("nodes.csv"));
// 			String line = reader.readLine();
// 			String[] ms = line.split(",");
// 			timeM = Long.parseLong(ms[0]);
// 			seqM = Long.parseLong(ms[1]);
			
// 			while(line != null){
// 				line = reader.readLine();
// 				String[] strs = line.split(",");
// 				int newNode = Integer.parseInt(strs[0]);
// 				Set<Integer> nodes = new HashSet();
// 				for(int i = 1; i < strs.length; i++){
// 					int node = Integer.parseInt(strs[i]);
// 					nodes.add(node);
// 					nodes2Newnode.put(node, newNode);
// 				}

// 				newnode2node.put(newNode, nodes);
// 			}
// 		}
// 		catch(Exception exp){}
// 		try{
// 			Connection conn = PostgreSQLJDBC.connDB(dbAddress,user,passwd);
// 			Statement statement = conn.createStatement();
// 			Scanner myObj = new Scanner(System.in);  // Create a Scanner object
// 			while(true){
// 				System.out.println("Enter node source id");
//     			String sourcId = myObj.nextLine();  // Read user input
//     			System.out.println("source id is: " + sourcId);  // Output user input

//     			System.out.println("Enter starttime");
//     			String statTime = myObj.nextLine();  // Read user input
//     			System.out.println("time is: " + statTime);  // Output user input
//     		//System.out.println("select * from filevent where A.dst == B.src == " + sourcId + "where B.starttime < " + statTime);  // Output user input
			
// 				int sourcIdInt = Integer.parseInt(sourcId);
// 			//Long statTimeL = Long.toString(statTime);
// 				singleQuery(statTime,sourcId, statement);
// 			}
// 		}
// 		catch(Exception exp){
// 			exp.printStackTrace(); 
//        		System.out.println(exp); 
// 		}
// 	}
		
// 	public static ArrayList<String> singleQuery(String statTime,String sourcId, Statement statement){
// 		ResultSet rs = null;
// 		ArrayList<String> ansList = new ArrayList<>();
// 		if(!nodes2Newnode.containsKey(sourcIdInt)){
// 			String query = "select * from fileevent where srcid=" + sourcId + " and starttime <= " + statTime + ";";
// 			System.out.println(query);
// 			if(statement.execute(query))
// 				rs = statement.getResultSet();
// 			ResultSetMetaData rsmd = rs.getMetaData();
// 			int columnsNumber = rsmd.getColumnCount();
// 			while(rs.next()){
// 				String ans = "";
// 				for(int i = 1; i <= columnsNumber;i++)
// 				ans = ans + rs.getString(i) + ",";
// 				System.out.println(ans);
// 			}
// 		}
// 		else{
// 			int newNode = nodes2Newnode.get(sourcIdInt);
// 			String query = "select * from fileevent where srcid=" + newNode + ";";
// 			if(statement.execute(query))
// 				rs = statement.getResultSet();
// 			ResultSetMetaData rsmd = rs.getMetaData();
// 			int columnsNumber = rsmd.getColumnCount();
// 			int pos = 0;
// 			Set<Integer> nodes = newnode2node.get(newNode);
// 			for(int n : nodes){
// 				if(n == sourcIdInt)
// 					break;
// 				pos++;
// 			}
// 		}
// 		String id = null, time = null, failure = null, srcid = null, dstid = null, 
// 		optype = null, agentid = null, path = null, access = null, amount = null, summarized = null;
// 		while(rs.next()){
// 			boolean found = false;
// 			List<String> results = new ArrayList();
// 			String starttime = null, starttime_seq = null, endtime = null, endtime_seq = null;
// 			for(int i = 1; i <= columnsNumber;i++){
// 			 	if(rsmd.getColumnName(i).equals("id"))	
// 			 		id = rs.getString(i);
// 			 	else if(rsmd.getColumnName(i).equals("starttime"))
// 					starttime = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("starttime_seq"))
// 					tarttime_seq = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("endtime"))
// 					endtime = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("endtime_seq")){
// 					String columnValue = rs.getString(i);
// 					String[] times = columnValue.split(";");
// 					starttime = starttime + " " + times[1];
// 					starttime_seq = starttime_seq + " " + times[2];
// 					endtime = endtime + " " + times[3];
// 					endtime_seq = times[0] + " " + times[4];
// 					String[] starttimes = starttime.split(" ");
// 					String[] starttimeSeqs = starttime_seq.split(" ");
// 					String[] endtimes = endtime.split(" ");
// 					String[] endtimeSeqes = endtime_seq.split(" ");

// 					String[] starttimesRes = decode(starttimes);
//     				String[] starttimeSeqsRes = decode(starttimeSeqs);
//     				String[] endtimesRes = decode(endtimes);
//     				String[] endtimeSeqesRes = decode(endtimeSeqes);

//     				if(isInteger(starttimes[pos+1])){// if not a merged node, check time
//  						if(starttimesRes[pos+1].equals(statTime)){
//  							time = starttimesRes[pos+1] + "," + starttimeSeqsRes[pos+1] + "," + endtimesRes[pos+1] + "," + endtimeSeqesRes[pos+1];
//  							results.add(time);
//  						}
//  					}
//  					else{
//  						String[] starttimesMerged = starttimes[pos+1].split("\\.");
//  						String[] starttimeSeqsMerged = starttimeSeqs[pos+1].split("\\.");
// 						String[] endtimesMerged = endtimes[pos+1].split("\\.");
//  						String[] endtimeSeqesMerged = endtimeSeqes[pos+1].split("\\.");
// 						starttimesMerged[0] = starttimesRes[pos+1];
//  						starttimeSeqsMerged[0] = starttimeSeqsRes[pos+1];
//  						endtimesMerged[0] = endtimesRes[pos+1];
//  						endtimeSeqesMerged[0] = endtimeSeqesMerged[pos+1];

//  						String[] s1 = Delta.decode(starttimesMerged);
// 						String[] s2 = Delta.decode(starttimeSeqsMerged);
//  						String[] s3 = Delta.decode(endtimesMerged);
//  						String[] s4 = Delta.decode(endtimeSeqesMerged);

//  						for(int j = 0; j < s1.length; j++){
//  							if(s1[j].equals(statTime)){
//  								time = s1[j] + "," + s2[j] + "," + s3[j] + "," + s4[j];
//  								results.add(time);
//  							}
//  						}
//  					}
//  				}
//  				else if(rsmd.getColumnName(i).equals("failure"))
// 					failure = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("srcid"))
// 					srcid =  sourcId;
// 				else if(rsmd.getColumnName(i).equals("dstid"))
// 					dstid = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("optype"))
// 					optype = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("agentid"))
// 					agentid = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("path"))
// 					path = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("access"))
// 					access = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("amount"))
// 					amount = rs.getString(i);
// 				else if(rsmd.getColumnName(i).equals("summarized"))
// 					summarized = rs.getString(i);
// 			}
// 			if(results.size() > 0){
// 				for(int i = 0; i < results.size();i++){
// 					String ans = id + "," + results.get(i) + "," + failure + "," + srcid + "," + dstid + "," + 
// 					agentid + "," + path + "," + access + "," + amount + "," + summarized;
// 					System.out.println(ans);
// 					ansList.add(ans);
// 				}
// 			}
// 		}
// 		System.out.println("");
//    }



// 	public static boolean isInteger(String s){
//       boolean isValidInteger = false;
//       s.replaceAll("\\s+","");
//       try
//       {
//         Long.parseLong(s);
//  		isValidInteger = true;
//       }
//       catch(NumberFormatException ex){}
//       return isValidInteger;
//    }

//    public static String[] decode(String[] strs){
//    		String[] strsList = strs;
//    		for(int i = 0; i < strs.length; i++){
//    			if(!isInteger(strs[i])){
//    				String tmp = strs[i].substring(1,strs[i].length()-1);

//  				String[] tmps = tmp.split("\\.");
//  				strsList[i] = tmps[0];
//  			}
//  			else strsList[i] = strs[i];
//  		}
//  		return Delta.decode(strsList);
//    }
// }