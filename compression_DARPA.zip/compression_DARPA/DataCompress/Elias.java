 package DataCompress;
 import java.lang.Math;
 import java.math.BigInteger; 
 public class Elias{
  	public static String encode(Long [] code, int length){
  		Long c = 0L;
  		if(code[1] < 0) c = -code[1]*2;
		else c = code[1]*2+1;
		BigInteger encoded = new BigInteger(Long.toString(c));
		int zeroLen = 0;

		for(int i = 2; i < length; i++){
			if(code[i] < 0) c = -code[i]*2;
			else c = code[i]*2+1;
  			if (zeroLen != log2(c)){
 				zeroLen = log2(c); 
 				encoded.shiftLeft(zeroLen);
 			}
 			encoded.shiftLeft(zeroLen+1);
 			encoded.or(BigInteger.valueOf(c));
		}
		return encoded.toString();
	}
	 public static Long[] decode(Long[] code, int length){
  		Long last = 0L;
  		Long[] encoded =  new Long[length];
		for(int i = 0;i < length; i++){
			Long current = code[i];
			encoded[i] = current - last;
			last = current;
		}
		return encoded;
	}
	// public static int[] delta_encode(int[] code, int length){

	// }
		public static int log2(long x)
	{
    	return (int) Math.floor(Math.log(x) / Math.log(2));
	}
  }