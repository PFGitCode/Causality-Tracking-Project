 package DataCompress;	
 public class Ricecoding{
	 public static long encode(long code, long M){
	 	long q = 0;
	 	long r = 0;
	 	q = code/M;
	 	r = code%M;
	 	long qBi = 0L;
	 	for(int i = 0; i < q; i++) 
	 		qBi = (qBi+1) << 1;
	 	Long temp = r;
	 	while(temp != 0){
	 		qBi = qBi << 1;
	 		temp = temp/2;
	 	}
	 	long decimalValue = qBi + r;
		return decimalValue;
	}
	// public static int[] delta_encode(int[] code, int length){

	// }
	public static long pow(final long base, long power) {
		long result = base;
		for (; power != 1; power--) {
			result = result * base;
		}
		return result;
	}
	public static long decode(final long encodeTime, final long M) {
		long swap = encodeTime;
		long residual = encodeTime;
		long i = 0L, j = 0L;
		long flag = 1;
		for (; swap != 0; i++)
			swap = swap / 2;
		i--;
		while (i > 0 && flag != 0) {
			flag = residual / pow(2, i);
			residual = residual % pow(2, i);
			j++;
			i--;
		}
		long decodeValue = (j * M) + residual;
		if(decodeValue % M != 0){
			decodeValue = decodeValue - M ;
		}
		return decodeValue;
	}
	public static void main(String[] args) {
		long time = 132071204286070894L;
		long encodeTime = encode(time,15627321722430067L);
		System.out.println(encodeTime);
	}
  }
