package DataCompress;  
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

public class PostgreSQLJDBC {
   public static Connection connDB(String address, String user,String password){
      Connection conn = null;
      try{ 
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(address,user,password);
         } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
         return conn;
      }
      return conn;
   }
   public static ResultSet readTable(Connection conn, String tableName,int limit, int offset) {
      ResultSet r = null;
      Statement statement  = null;
      try { 
         conn.setAutoCommit(false);
         statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); 
      //   statement = conn.createStatement();      
         statement.setFetchSize(10);
         String SQL = "SELECT * FROM "+tableName + " ORDER BY id ASC"+" LIMIT "+ Integer.toString(limit) + " OFFSET " + Integer.toString(offset);
         //CopyManager copyManager = new CopyManager(con);
         r = statement.executeQuery(SQL);
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
         return r;
      }
     // statement.close();
      return r;
   }
   public static ResultSet readAll(Connection conn, String tableName) {
      ResultSet r = null;
      Statement statement  = null;
      try { 
         conn.setAutoCommit(false);
         statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); 
      //   statement = conn.createStatement();      
         statement.setFetchSize(10);
       //  String SQL = "SELECT * FROM "+tableName + " ORDER BY id ASC";
         String SQL = "SELECT * FROM "+tableName;
         //CopyManager copyManager = new CopyManager(con);
         r = statement.executeQuery(SQL);
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
         return r;
      }
     // statement.close();
      return r;
   }
   public static void deleteTable(Connection conn, String tableName) {
      try {  
            Statement statement = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
            statement.executeUpdate("DELETE FROM " + tableName);
      } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }
     // statement.close();
   }
   public static void createTable(Connection conn, String tableName) {
      try {  
      Statement statement = conn.createStatement();
      String SQL = 
   "CREATE TABLE public." + tableName+" ( id integer NOT NULL, starttime bigint, starttime_seq bigint,endtime bigint,endtime_seq text, failure integer, srcid integer NOT NULL, dstid integer NOT NULL, optype public.optype, agentid integer, path integer, access public.accessright,amount bigint, summarized integer );";
      statement.executeUpdate(SQL);
     // statement.close();
   } catch (Exception e) {
         e.printStackTrace();
         System.err.println(e.getClass().getName()+": "+e.getMessage());
         System.exit(0);
      }
   }
}