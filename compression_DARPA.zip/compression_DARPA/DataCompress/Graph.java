 package DataCompress;	
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.*;
import java.util.ArrayList;
import  java.lang.Math;
import java.util.*;
import java.util.Collections; 
import java.util.Arrays; 

public class Graph {
   static int[] nodeHash = new int[50000000];
   static int maxNodeId = 0;
   static int newNodeId = -1;
   static Set<Integer> set = new HashSet();
//   static int maxEdgeId = 0;
   Map<String, Set<String>> graphMap = new HashMap<>();
   // Map<Integer, Set<Integer>> inverseGraphMap = new HashMap<>();
   Map<Integer, Set<Integer>> newNode2nodes = new HashMap<>();
   Map<List<Integer>, List<Edge>> edgeInfo = new HashMap<>();
   Map<List<String>, Edge> nodesEdgeMerged = new HashMap<>();
   Map<List<String>, Edge> nodesEdgeMerged_Multi = new HashMap<>();

   List<Edge> edgeIndex = new ArrayList();
   Map<Integer, Integer> nodesIndexMap = new HashMap<>(); // node index

  public void addEdge(Edge ed){
    // System.out.println(ed.srcid);
    // System.out.println(ed.dstid);
    // Integer srcindex = Integer.parseInt(ed.srcid.replace("-", ""),16);
    // Integer dstindex = Integer.parseInt(ed.dstid.replace("-", ""),16);
  //  if(srcindex == dstindex) return;
    // maxNodeId = Math.max(dstindex,maxNodeId);
    // maxNodeId = Math.max(srcindex,maxNodeId);
    
  //  int id = Integer.parseInt(ed.srcid);

    // List<Integer> nodes = new ArrayList();
    // nodes.add(srcindex);
    // nodes.add(dstindex);

    // edgeInfo.putIfAbsent(nodes, new ArrayList());
    // edgeInfo.get(nodes).add(ed);

    // graphMap.putIfAbsent(srcindex, new HashSet());
    // graphMap.get(srcindex).add(dstindex);

    // inverseGraphMap.putIfAbsent(dstindex, new HashSet());
    // inverseGraphMap.get(dstindex).add(srcindex);
  }
// when isInverse = false, merging parents having the same children, map<childrenList, parentslist>
// when isInverse = true, merging children having the same parents, map<parentslist, childrenList>
  // public Map<Set<Integer>, Set<Integer>> findDup(boolean isInverse){
  //   Map<Set<Integer>, Set<Integer>> nameAndCount = new HashMap<>(); 
  //   Map<String, Set<String>> tempMap;
  //   if(isInverse == false)
  //     tempMap = graphMap;
  //   else
  //     tempMap = inverseGraphMap;

  //   for (Integer srcindex : graphMap.keySet()) {
  //     Set<Integer> childrenSet = new HashSet<>(graphMap.get(srcindex));
  //     if (childrenSet.size() == 0) continue;

  //     nameAndCount.putIfAbsent(childrenSet,new HashSet());
  //     nameAndCount.get(childrenSet).add(srcindex);
  //   }
  //   return nameAndCount;
  // }

  // public void sameNodeMerging(){
  //   Edge newEdge;
  //   for (List<String> nodes : edgeInfo.keySet()) {
  //     List<Edge> edge_list = edgeInfo.get(nodes);
  //     if (edge_list.size() > 1)
  //       newEdge = mergeEdgeSameNodes(edge_list);
  //     else
  //       newEdge = edge_list.get(0);

  //     nodesEdgeMerged.put(nodes, newEdge);
  //   }
  // }

  // public void diffNodeMerging(Map<Set<Integer>, Set<Integer>> child2parent) {
  //   int totalC = 0;
  //   for (Set<Integer> children : child2parent.keySet()) {
  //     Set<Integer> parents = child2parent.get(children);
  //     if (parents.size() > 1) {
  //       newNode2nodes.put(newNodeId, parents);

  //       for (int child : children) {
  //         ArrayList<Edge> es = new ArrayList();
  //         for (int parent : parents) {
  //           List<Integer> nodes = new ArrayList();
  //           nodes.add(parent);
  //           nodes.add(child);

  //           Edge edlist = nodesEdgeMerged.get(nodes);
  //           es.add(edlist);
  //         }

  //         Edge newEdge = mergeEdgeDiffNodes(es);
  //         List<Integer> nodes = new ArrayList();
  //         nodes.add(newNodeId);
  //         nodes.add(child);

  //         nodesEdgeMerged_Multi.put(nodes, newEdge);
  //       }
  //       newNodeId--;
  //       maxNodeId++;
  //     } 
  //     else {
  //      for(int child : children){
  //         for(int parent : parents){
  //           List<Integer> nodes = new ArrayList();
  //           nodes.add(parent);
  //           nodes.add(child);
  //           nodesEdgeMerged_Multi.put(nodes, nodesEdgeMerged.get(nodes));
  //           totalC++;
  //         }
  //       }
  //     }
  //   }
  //   // System.out.println("totalC");
  //   // System.out.println(totalC);
  // }

  // public Edge mergeEdgeSameNodes(List<Edge> es){
  //   int length = es.size();
  //   Long[] starttimes = new Long[length];
  //   Long[] starttime_seqs = new Long[length];
  //   Long[] endtimes = new Long[length];
  //   Long[] endtime_seqs = new Long[length];

  //   for (int i = 0; i < length; i++) {
  //     starttimes[i] = Long.parseLong(es.get(i).starttime);
  //     starttime_seqs[i] = Long.parseLong(es.get(i).starttime_seq);
  //     endtimes[i] = Long.parseLong(es.get(i).endtime);
  //     endtime_seqs[i] = Long.parseLong(es.get(i).endtime_seq);
  //   }

  //   Arrays.sort(starttimes, Collections.reverseOrder());
  //   Arrays.sort(starttime_seqs, Collections.reverseOrder());
  //   Arrays.sort(endtimes, Collections.reverseOrder());
  //   Arrays.sort(endtime_seqs, Collections.reverseOrder());

  //   starttimes = Delta.encode(starttimes, length);
  //   starttime_seqs = Delta.encode(starttime_seqs, length);
  //   endtimes = Delta.encode(endtimes, length);
  //   endtime_seqs = Delta.encode(endtime_seqs, length);

  //   String starttime = Long.toString(starttimes[0]);
  //   String starttime_seq = Long.toString(starttime_seqs[0]);
  //   String endtime = Long.toString(endtimes[0]);
  //   String endtime_seq = Long.toString(endtime_seqs[0]);

  //   String endtime_delta = "", endtime_seq_delta = "", starttime_delta = "", starttime_seq_delta = "";
  //   for (int i = 1; i < length; i++) {
  //     endtime_delta = endtime_delta + Long.toString(endtimes[i]) + ".";
  //     endtime_seq_delta = endtime_seq_delta + Long.toString(endtime_seqs[i]) + ".";
  //     starttime_delta = starttime_delta + Long.toString(starttimes[i]) + ".";
  //     starttime_seq_delta = starttime_seq_delta + Long.toString(starttime_seqs[i]) + ".";
  //   }

  //   endtime_seq = endtime_seq + ';' + starttime_delta + ';' + starttime_seq_delta + ';' + endtime_delta + ';' + endtime_seq_delta;
  //   String line = es.get(0).id + "," + starttime + "," + starttime_seq + "," + endtime + "," + endtime_seq + "," + es.get(0).failure + ","
  //       + es.get(0).srcid + "," + es.get(0).dstid + "," + es.get(0).optype + "," + es.get(0).agentid + "," + es.get(0).path + "," + es.get(0).access + "," + es.get(0).amount + ","
  //       + es.get(0).summarized;
  //   return new Edge(line);
  // }

  // public Edge mergeEdgeDiffNodes(List<Edge> es) {
  //   int length = es.size();
  //   String srcid = "", dstid = "";
  //   if (es.get(0).srcid.equals(es.get(1).srcid)){
  //       srcid = es.get(0).srcid;
  //       dstid = Long.toString(maxNodeId);
  //   }      
  //   else if(es.get(0).dstid.equals(es.get(1).dstid)){
  //       dstid = es.get(0).dstid; 
  //       srcid = Long.toString(maxNodeId);
  //   }
  //   else{
  //       System.out.println("error");
  //   }

  //   Set<Integer> bracketPos = new HashSet(); //brakcet for nodes that have merged edges.
  //   List<String> starttimesMerged = new ArrayList();
  //   List<String> starttime_seqsMerged = new ArrayList();
  //   List<String> endtimesMerged = new ArrayList();
  //   List<String> endtime_seqsMerged = new ArrayList();

  //   Long[] starttimes = new Long[length + 1];  // add 1 for the max value
  //   Long[] starttime_seqs = new Long[length + 1];
  //   Long[] endtimes = new Long[length + 1];
  //   Long[] endtime_seqs = new Long[length + 1];
  //   starttimes[0] = 0L;
  //   starttime_seqs[0] = 0L;
  //   endtimes[0] = 0L;
  //   endtime_seqs[0] = 0L;

  //   for (int i = 1; i < length + 1; i++) {
  //       starttimes[i] = Long.parseLong(es.get(i-1).starttime);
  //       starttime_seqs[i] = Long.parseLong(es.get(i-1).starttime_seq);
  //       endtimes[i] = Long.parseLong(es.get(i-1).endtime);

  //       String[] seqs = es.get(i - 1).endtime_seq.split(";");
  //       endtime_seqs[i] = Long.parseLong(seqs[0]);

  //       if(seqs.length > 1){// found a merged edges
  //         bracketPos.add(i);
  //         starttimesMerged.add(seqs[1]);
  //         starttime_seqsMerged.add(seqs[2]);
  //         endtimesMerged.add(seqs[3]);
  //         endtime_seqsMerged.add(seqs[4]);
  //       }
  //   }

  //   starttimes[0] = Collections.max(Arrays.asList(starttimes));
  //   starttime_seqs[0] = Collections.max(Arrays.asList(starttime_seqs));
  //   endtimes[0] = Collections.max(Arrays.asList(endtimes));
  //   endtime_seqs[0] = Collections.max(Arrays.asList(endtime_seqs));

  //   starttimes = Delta.encode(starttimes, length + 1);
  //   starttime_seqs = Delta.encode(starttime_seqs, length + 1);
  //   endtimes = Delta.encode(endtimes, length + 1);
  //   endtime_seqs = Delta.encode(endtime_seqs, length + 1);

  //   String starttime = Long.toString(starttimes[0]);
  //   String starttime_seq = Long.toString(starttime_seqs[0]);
  //   String endtime = Long.toString(endtimes[0]);
  //   String endtime_seq = Long.toString(endtime_seqs[0]);

  //   String endtime_delta = "", endtime_seq_delta = "", starttime_delta = "", starttime_seq_delta = "";

  //   int posNum = 0;
  //   for (int i = 1; i < length+1; i++) {
  //     if(bracketPos.contains(i)){
  //       endtime_delta = endtime_delta + "(";
  //       endtime_seq_delta = endtime_seq_delta + "(";
  //       starttime_delta = starttime_delta + "(";
  //       starttime_seq_delta = starttime_seq_delta + "(";

  //       endtime_delta = endtime_delta + Long.toString(endtimes[i]);
  //       endtime_seq_delta = endtime_seq_delta + Long.toString(endtime_seqs[i]);
  //       starttime_delta = starttime_delta + Long.toString(starttimes[i]);
  //       starttime_seq_delta = starttime_seq_delta + Long.toString(starttime_seqs[i]);

  //       starttime_delta = starttime_delta + "." + starttimesMerged.get(posNum) + ") ";
  //       starttime_seq_delta = starttime_seq_delta + "." + starttime_seqsMerged.get(posNum) + ") ";
  //       endtime_delta = endtime_delta + "." + endtimesMerged.get(posNum) + ") ";
  //       endtime_seq_delta = endtime_seq_delta + "." + endtime_seqsMerged.get(posNum) + ") ";
  //       posNum++;
  //     }
  //     else{
  //       endtime_delta = endtime_delta + Long.toString(endtimes[i]) + " ";
  //       endtime_seq_delta = endtime_seq_delta + Long.toString(endtime_seqs[i]) + " ";
  //       starttime_delta = starttime_delta + Long.toString(starttimes[i]) + " ";
  //       starttime_seq_delta = starttime_seq_delta + Long.toString(starttime_seqs[i]) + " ";
  //     }
  //   }

  //   endtime_seq = endtime_seq + ';' + starttime_delta + ';' + starttime_seq_delta + ';' + endtime_delta + ';'
  //       + endtime_seq_delta;

  //   String line = es.get(0).id + "," + starttime + "," + starttime_seq + "," + endtime + "," + endtime_seq + "," + es.get(0).failure + ","
  //       + srcid + "," + dstid + "," + es.get(0).optype + "," + es.get(0).agentid + "," + es.get(0).path + "," + es.get(0).access + "," + es.get(0).amount + ","
  //       + es.get(0).summarized;
  //   return new Edge(line);
  // }

  // public static List<Edge> decode(Edge e) {
  //   List<Edge> edgeList = new ArrayList<>();
  //   String[] seqs = e.endtime_seq.split(";");
  //   if (seqs.length == 1){
  //     edgeList.add(e);
  //     return edgeList;
  //   }

  //   String endtimeSeq = seqs[0] + " " + seqs[2];
  //   String endtime = e.endtime + " " + seqs[1];
  //   String starttime = e.starttime + " " + seqs[3];
  //   String starttimeSeq = e.starttime_seq + " " + seqs[4];

  //   String[] endtimeSeqes = Delta.decode(endtimeSeq.split(" "));
  //   String[] endtimes = Delta.decode(endtime.split(" "));
  //   String[] starttimes = Delta.decode(starttime.split(" "));
  //   String[] starttimeSeqs = Delta.decode(starttimeSeq.split(" "));

  //   int edgeNum = endtimeSeqes.length;
  //   // for current use
  //   if (edgeNum == 1) {
  //     edgeList.add(e);
  //     return edgeList;
  //   }

  //   for (int i = 0; i < edgeNum; i++) {
  //     String line = e.id + "," + starttimes[i] + "," + starttimeSeqs[i] + "," + endtimes[i] + "," + endtimeSeqes[i]
  //         + "," + e.failure + "," + e.srcid + "," + e.dstid + "," + e.optype + "," + e.agentid + "," + e.path + ","
  //         + e.access + "," + e.amount + "," + e.summarized;
  //     Edge newEdge = new Edge(line);
  //     edgeList.add(newEdge);
  //   }
  //   return edgeList;
  // }
  // public List<Integer> findNodesWithNoParents(){
  //   List<Integer> nodesWithNochildrenList = new ArrayList();
  //   for (Integer srcindex : graphMap.keySet()) {
  //     List childrenList = inverseGraphMap.get(srcindex);
  //     if (childrenList == null)
  //       nodesWithNochildrenList.add(srcindex);
  //   }
  //   return nodesWithNochildrenList;
  // }

  // public void removeEdge(Edge ed) {
  //   edgeNumber--;
  //   edgeIndex.remove(ed);
  //   int srcid = 0;
  //   int dstid = 0;
  //   if (ed.access.equals("0") || ed.access.equals("Execute")) {
  //     dstid = Integer.parseInt(ed.srcid);
  //     srcid = Integer.parseInt(ed.dstid);
  //   } else if (ed.access.equals("1") || ed.access.equals("Read_Content")) {
  //     dstid = Integer.parseInt(ed.srcid);
  //     srcid = Integer.parseInt(ed.dstid);
  //   } else if (ed.access.equals("2") || ed.access.equals("Write_Content")) {
  //     srcid = Integer.parseInt(ed.srcid);
  //     dstid = Integer.parseInt(ed.dstid);
  //   }
  //   Integer srcindex = nodesIndexMap.get(srcid);
  //   Integer dstindex = nodesIndexMap.get(dstid);

  //   deleteGraphMap(graphMap, srcindex, dstindex);
  //   deleteGraphMap(inverseGraphMap, dstindex, srcindex);
  //   removeEdgeInfo(nodesEdge, srcindex, dstindex);
  //   removeEdgeInfo(inverseNodesEdge, dstindex, srcindex);

  // }

  // public List bfs(int start, List<List<Integer>> graph, int nodesNum) {
  //   List descendants = new ArrayList();
  //   Integer[] prev = new Integer[nodesNum];
  //   boolean[] visited = new boolean[nodesNum];
  //   Deque<Integer> queue = new ArrayDeque<>(nodesNum);

  //   // Start by visiting the 'start' node and add it to the queue.
  //   queue.offer(start);
  //   visited[start] = true;

  //   // Continue until the BFS is done.
  //   while (!queue.isEmpty()) {
  //     int node = queue.poll();
  //     List<Integer> tos = graph.get(node);

  //     // Loop through all edges attached to this node. Mark nodes as visited once
  //     // they're
  //     // in the queue. This will prevent having duplicate nodes in the queue and
  //     // speedup the BFS.
  //     for (int to : tos) {
  //       if (!visited[to]) {
  //         descendants.add(to);
  //         visited[to] = true;
  //         prev[to] = node;
  //         queue.offer(to);
  //       }
  //     }
  //   }
  //   return descendants;
  // }

  // public static void updateGraphMap(Map<Integer, List<Integer>> gMap, int srcindex, int dstindex) {
  //   List<Integer> dsList = gMap.get(srcindex);
  //   if (dsList == null)
  //     dsList = new ArrayList();
  //   if (!dsList.contains(dstindex))
  //     dsList.add(dstindex);
  //   gMap.put(srcindex, dsList);
  // }

  // public static void deleteGraphMap(Map<Integer, List<Integer>> gMap, int srcindex, int dstindex) {
  //   List<Integer> dsList = gMap.get(srcindex);
  //   if (dsList == null)
  //     return;
  //   if (dsList.contains(dstindex))
  //     dsList.remove(new Integer(dstindex));
  //   if (dsList.size() > 0)
  //     gMap.put(srcindex, dsList);
  //   else if (dsList.size() == 0)
  //     gMap.remove(srcindex);
  // }

  // public static void removeEdgeInfo(Map<List<Integer>, List<Edge>> nEdge, int srcindex, int dstindex) {
  //   List nodes = new ArrayList();
  //   nodes.add(srcindex);
  //   nodes.add(dstindex);
  //   nEdge.remove(nodes);
  // }
}