package DataCompress; 
import java.util.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.*;
import java.util.ArrayList;
import static java.lang.Math.min;
import java.util.*;
import java.sql.ResultSet;
import java.sql.Connection;
import java.sql.Statement;

public class test{
  public static void main(String[] args) {
    String csv_file_name = args[0];
    BufferedReader reader = null;
    // BufferedWriter writer = null;
    // BufferedWriter writerNode = null;
    int totalEvent = 0;
    try{
      reader = new BufferedReader(new FileReader(csv_file_name));
      // writer = new BufferedWriter(new FileWriter("CompressedFileevent.csv")); 
      // writerNode = new BufferedWriter(new FileWriter("nodes.csv")); 

      String line = reader.readLine();
      Graph graph = new Graph();
      while(line != null){
        System.out.println(line);
        int i = 0;
        while(i >= 0){
        int j = 0;
        }
        Edge ed = new Edge(line);
        graph.addEdge(ed);
        totalEvent++;
        line = reader.readLine();
      } 
      System.out.println(totalEvent);
      // Map<List<String>, List<Edge>> edgeInfo = graph.edgeInfo;
      // System.out.println(edgeInfo.size());
       //  System.out.println(graph.maxNodeId);
       // System.out.println(Edge.seqM);
        //Rice coding
        // for(List<Edge> elist : graph.edgeInfo.values())
        //   for(Edge e : elist)
        //     e.RiceEncode();

        // StringBuilder mS = new StringBuilder(); 
        // mS.append(Edge.timeM);
        // mS.append(",");
        // mS.append(Edge.seqM);
        // writerNode.write(mS.toString());
        // writerNode.newLine();  
        //merge edges between 2 nodes.
    //     graph.sameNodeMerging();

    //     boolean isInverse = true;
    //     Map<Set<Integer>, Set<Integer>> child2parent = graph.findDup(isInverse);
    //     graph.diffNodeMerging(child2parent);
    //     Map<List<Integer>,Edge> nE = graph.nodesEdgeMerged_Multi;
    //     for(Edge e:nE.values()){
    //       writer.write(e.total);
    //       newtotalEvent++;
    //       writer.newLine();  
    //     }

    //     Map<Integer, Set<Integer>>  newNode2nodes = graph.newNode2nodes;
    //     for(int newNode:newNode2nodes.keySet()){
    //       StringBuilder nodesStr = new StringBuilder();
    //       nodesStr.append(newNode);
    //       for(int n : newNode2nodes.get(newNode)){
    //         nodesStr.append(',');
    //         nodesStr.append(n);
    //       }
    //       writerNode.write(nodesStr.toString());
    //       writerNode.newLine();  
    //       newNodesNum++;
    //     }

    //     System.out.print(Integer.toString(iter)+ ",");
    //     graph = null;
    //   }
    //   rs.close(); 
    //   writer.close(); 
    //   writerNode.close(); 
    }catch(Exception exp) {
        exp.printStackTrace(); 
        System.out.println(exp); 
    }  

    // System.out.println(totalEvent);
    // System.out.println(newtotalEvent);
  }
}
