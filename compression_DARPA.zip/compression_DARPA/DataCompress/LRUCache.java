//package DataCompress;  
// import java.util.*;
// import java.io.BufferedReader;
// import java.io.FileReader;
// import java.io.BufferedWriter;
// import java.io.FileWriter;
// import java.io.IOException;
// import java.lang.*;
// import java.util.ArrayList;
// import java.util.*;

// class LRUCache extends LinkedHashMap<List<Integer>,List<Edge>>{
//     private int capacity;
    
//     public LRUCache(int capacity) {
//         super(capacity, 0.75F, true);
//         this.capacity = capacity;
//     }

//     public int get(int key) {
//         return super.getOrDefault(key, -1);
//     }

//     public void put(int key, int value) {
//         super.put(key, value);
//     }

//     @Override
//     protected boolean removeEldestEntry(Map.Entry<List<Integer>,List<Edge>> eldest) {
//         return size() > capacity; 
//     }
// }