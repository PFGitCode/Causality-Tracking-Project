 package DataCompress;
 import java.util.Arrays;
 public class Delta{
  	public static int[] encode(int[] code, int length){
  		int last = 0;
  		int[] encoded =  new int[length];
		for(int i = 0;i < length; i++){
			int current = code[i];
			encoded[i] = current - last;
			//System.out.println(encoded[i]);
			last = current;
		}
		return encoded;
	}
	 public static Long[] encode(Long[] code, int length){
  		Long last = 0L;
  		Long[] encoded =  new Long[length];
		for(int i = 0;i < length; i++){
			Long current = code[i];
			encoded[i] = current - last;
			last = current;
		}
		return encoded;
	}

	public static String[] decode(String[] code){
		int length = code.length;
		if(length == 1) return code;
  		Long last = 0L;
  		String[] decoded =  new String[length];
 
    	for (int i = 0; i < length; i++){
    		Long delta = Long.parseLong(code[i]);
        	decoded[i] = Long.toString(delta + last);
        	last = Long.parseLong(decoded[i]);
	    }	
	    // System.out.println(Arrays.toString(code));
	    // System.out.println(Arrays.toString(decoded));
	    //         try {
     //                Thread.sleep(1000000);                 //1500 milliseconds is one second.
     //              } catch(InterruptedException ex) {
     //                Thread.currentThread().interrupt();
     //          }
		return decoded;
	}
	// public static int[] delta_encode(int[] code, int length){

	// }
  }
