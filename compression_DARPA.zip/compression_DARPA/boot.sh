#set -e
CSVFILE="test2.csv"


javac DataCompress/*.java
java -classpath DataCompress/postgresql-42.2.6.jar:./ DataCompress.test $CSVFILE
