#createdb darpa
USERNAME="peng"
PASSWARD="1234"
DATABASENAME="darpa"
DATABASEADDRESS="jdbc:postgresql://localhost:5432/darpa"
psql -U $USERNAME -d compresseddb -c "CREATE TABLE fileevent (UUID char(5), LATITUDE double precision, LONGITUDE double precision, 
CITY varchar, STATE char(2), COUNTY varchar, ZIP_CLASS varchar);"
